/*
 * peripherals implementation file, adapted
 * from Confer's robots miniat example 
 * William Blair
 * 03/06/17 */

#include "peripherals.h"

#include <iostream>

/* defines from main.cpp */
const int S_WIDTH  = 1024; // window dimensions
const int S_HEIGHT = 768;

/*
 * William Blair 
 * 03/06/17
 * clock_peripherals - updates the miniat bus each cycle */
bool clock_peripherals(miniat *m, Sprite &heli, int &thrustY, double &vY,
                       unsigned int &lives)
{
	m_bus bus; // an object of the current miniat's peripheral bus
	
	/* make sure miniat isn't null when given */
	if(!m){
		std::cerr << "MiniAT NULL this clock cycle!\n";
		return false;
	}
	
	/* get the current miniat bus */
	bus = miniat_pins_bus_get(m);
	
	/* check if there has been an acknowledgement request */
	if(bus.req == M_HIGH && bus.ack == M_LOW)
	{
		bool handled = true; // to show that yep, we've handled the request
		if(bus.rW == M_HIGH)
		{
			/* store data in the different peripherals here */
			switch(bus.address)
			{
				case P_THRUST: // in our case only the thrust is writable
					std::cout << "\nSTORed to the P_THRUST peripheral\n";
					
					/* test if the new thrust is valid */
					if( (signed)bus.data < -100 || (signed)bus.data > 100 ){
						std::cerr << "Invalid Thrust: " << (signed)bus.data << ", Must be between [-100, 100]\n";
					}
					else{
						/* negated to compensate for confer's assembly 
						 * this makes positive thrust make the helicopter go up instead of down */
						thrustY = -1 * (int)((signed)bus.data);
						//thrustY = (int)((signed)bus.data);
						std::cout << "Address = 0x" << std::hex << bus.address <<
						std::dec << "\tData = " << (signed int)bus.data << std::endl;
					}
					break;
				default:
					std::cerr << "Invalid STOR address: " << bus.address << std::endl;
					
					/* Maybe set handled here to false but confers example doesn't have it built in */
					
					break;
			}
		}
		else
		{
			/* LOAD data from peripherals */
			switch(bus.address)
			{
				/* read the current y thrust */
				case P_THRUST:
					std::cout << "\nLOADed from P_THRUST\n";
					/* invert to give illusion of reversed up and down (since sdl up/down is reverse) */
					bus.data = thrustY;
					std::cout << "Address = 0x" << std::hex << bus.address <<
					std::dec << "\tData = " << (signed int)bus.data << std::endl;
					break;
					
				/* read the current helicopter y position */
				case P_Y:
					std::cout << "\nLOADed from P_Y\n";
					//commented to adapt to confer's code
					bus.data = S_HEIGHT - heli.getY();
					//bus.data = heli.getY();
					std::cout << "Address = 0x" << std::hex << bus.address <<
					std::dec << "\tData = " << bus.data << std::endl;
					break;
				/* read the current helicopter y velocity */
				case P_Y_VELOCITY:
					std::cout << "\nLOADed from P_Y_VELOCITY\n";
					// commenting to change to negative to follow confer's assembly
					//bus.data = vY;
					bus.data = -1* vY;
					std::cout << "Address = 0x" << std::hex << bus.address <<
					std::dec << "\tData = " << (signed)bus.data << std::endl;
					break;
				
				/* read the current number of lives the player has */
				case P_LIVES:
					std::cout << "\nLOADed from P_LIVES\n";
					bus.data = lives;
					std::cout << "Address = 0x" << std::hex << bus.address <<
					std::dec << "\tData = " << bus.data << std::endl;
					break;
					
				/* TODO - implement me when victims are combined with this */
				case P_VICTIM_DIST:
					std::cout << "LOADed from P_VICTIM_DIST\n";
					break;
				case P_VICTIM_Y:
					std::cout << "LOADed from P_VICY\n";
					break;

				case P_GROUND_DIST:
					std::cout << "LOADed from P_GROUNDIS\n";
					break;
				case P_GROUND_HEIGHT:
					std::cout << "LOADed from P_GROUNDH\n";
					break;
				case P_CEIL_DIST:
					std::cout << "LOADed from P_CEIL_DIST\n";
					break;
				case P_CEIL_HEIGHT:
					std::cout << "LOADed from P_CEIL_HEIGHT\n";
					break;
				default:
					std::cerr << "Invalid address to read from: " << bus.address << std::endl;
					break;
			}
		}
		
		/* if no errors during handling, set the acknowledge pin to HIGH */
		if(handled){
			bus.ack = M_HIGH;
		}
	}
	else if(bus.ack){
		/* this is where if you want to add delay to some peripherals 
		 * you would do that here */
		switch(bus.address)
		{
			default:
				bus.ack = M_LOW;
				break;
		}
	}
	
	/* finally write the new bus to the miniat */
	miniat_pins_bus_set(m, bus);
	
	return true;
}

