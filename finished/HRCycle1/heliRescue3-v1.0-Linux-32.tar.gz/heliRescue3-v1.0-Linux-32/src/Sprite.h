/*
 * William Blair
 * CS370
 * 02/20/17
 * Sprite.h - sprite class for heligame rescue
 * */
 
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>

#include <iostream>

#ifndef _SPRITE_H_
#define _SPRITE_H_

class Sprite
{
	public:
	
		/* Constructor */
		Sprite(const char *filename, SDL_Renderer *r);
		Sprite();
		
		/* DeConstructor */
		~Sprite();
		
		/* load a new or initial image */
		bool load(const char *filename, SDL_Renderer *r);
		
		/* free the internal texture */
		void free(void);
		
		/* draw the texture to a renderer */
		bool draw(SDL_Renderer *r);
		
		/* Getter Functions */
		SDL_Texture *getTexture(void);
		int          getX(void);
		int          getY(void);
		int          getW(void);
		int          getH(void);
		
		/* setter functions */
		void setX(int x);
		void setY(int y);
		//bool optimize(SDL_Surface *s); // optimize the image based on the display surface
	
	private:
	
		SDL_Texture *t;        // holds the image
		SDL_Rect     clipRect; // internal size/position of the image
		
		int x,y;               // the x and y position of the image
};

#endif 
