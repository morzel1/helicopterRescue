/*
 * William Blair
 * CS370
 * 02/16/17
 * main.cpp - skeleton for
 * Helicopter Rescue Game */

////////////////////////////////////
//     HEADER FILES / INCLUDES    //
////////////////////////////////////
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <stdlib.h>
#include <iostream>

#include "Sprite.h"

/* MiniAT includes */
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <stdint.h>
#include <inttypes.h>

#include <miniat.h>
#include "peripherals.h"
#include "ports.h"

/* define from robots example code */
#define MAX_CYCLES UINT64_MAX

/* temporary windows fix for bj compiling */
#ifdef __WIN32
	#undef main
#endif

////////////////////////////////////
//      DEFINES / CONSTANTS       //
////////////////////////////////////

const int S_WIDTH  = 1024; // window dimensions (1024)
const int S_HEIGHT = 768;   //786

/***** JUST FOR PRESENTATION - CHANGE ME AFTER BUILD *****/
const int SCROLL_SPEED = 3;
const int FPS = 60;
/*********************************************************/

const char title[] = "Heli Rescue"; // title of the window
const int MAX_THRUST = 100; // the max miniat function value
                            // for thrust we're planning to use
							
const double MAX_VEL  = 5.0;  // the most amount of pixels the sprite can move per frame
/////////////////////////////////////
//       FUNCTION DECLARATIONS     //
/////////////////////////////////////

bool initSDL(void);
bool createWindow(SDL_Window **w);

void calcVelocity(Sprite &heli, int thrustX, int thrustY, double &vX, double &vY);
bool initMiniAT(miniat **m, int argc, char *argv[]);

/* modified from robots example */
static void cleanMiniAT(miniat **m);
static void signal_handler(int sig);

/* mike's scrolling background */
const int cameraWidth = 1024;
const int cameraHeight = 768;

SDL_Rect cameraRect = {0,0,cameraWidth,cameraHeight};

//This block is what gives the value on line 55 its value
SDL_Texture *LoadTexture(std::string filePath, SDL_Renderer *renderTarget){
    SDL_Texture *texture = NULL;
    SDL_Surface *surface = SDL_LoadBMP(filePath.c_str());
    if(surface == NULL){
        std::cout << "error" << std::endl;
    }
    else{
        texture = SDL_CreateTextureFromSurface(renderTarget,surface);
        if(texture==NULL){
        std::cout << "error" << std::endl;
    }
    SDL_FreeSurface(surface);
    return texture;
}
}

//////////////////////////////////////
//              MAIN                //
//////////////////////////////////////
int main(int argc, char *argv[])
{
	/////////////////////////////////
	//       LOCAL VARIABLES       //
	/////////////////////////////////
	SDL_Window   *window   = NULL;  // the application window
	SDL_Renderer *renderer = NULL;  // renders the screen
	
	/* miniat variables */
	miniat *m       = NULL; // the main 'miniat' object
	int cycles      = 0;    // the number of cycles the miniat has run
	//char   *asmFile = NULL; // the miniat assembly file to load
	//char   *binFile = NULL; // the miniat bin file to load
	
	/* BJ added - initialize miniat */
	if( !initMiniAT(&m, argc, argv) ){
		return -1;
	}
	
	//Create x and y location arrays.
    int victimLocY[5];
    int victimLocX[5];

    /*Nested for loop to "randomly generate"
    x and y coordinates for each
    victim to spawn at
    */
    for(int i = 0; i <5; i++)
    {
        for(int j=0; j<5; j++)
        {
            victimLocX[i] = rand() % 1025 - 23;
            victimLocY[j] = rand() % 769 - 55;
        }
    }

    /*//////////////////////////////////////////////////
    Create the Rects for the "victims" to be drawn to,//
    and print out their location to the console     ////
    Nicolas VonDollen                       ////////////
    CS 370  ////////////////////////////////////////////
    2/20/17 ////////////////////////////////////////////
    //////////////////////////////////////////////////*/

	bool isRunning = true;          // false when the game exits
	SDL_Event event;                // holds events like keypresses, etc.

	Sprite heli; // use the no args constructor since no libraries have been initted
	unsigned int lives = 5; // how many freebies the helicopter has
	int    thrustX = 0; // the thrust to apply to the helicopter
	int    thrustY = 0;
	double    vX      = 0; // the helicopter's velocity
	double    vY      = 0;

	Sprite victim1, victim2, victim3, victim4, victim5, victim6, victim7,
	       victim8, victim9, victim10; //create 10 victims in this build of the code

    Sprite objarray[10]; //amount of building generated


	/* initialze SDL, IMG, and TTF Libraries
	 * quit the program on failure*/
	if( !initSDL() ){
		return -1;
	}
	/* create the window for the application */
	if( !createWindow(&window) ){
		IMG_Quit();
		TTF_Quit();
		SDL_Quit();
		return -1;
	}


	/* create the renderer for the window */
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if( !renderer ) {
		std::cerr << "Failed to create renderer: " << SDL_GetError()
		                                           << std::endl;
		SDL_DestroyWindow(window);
		IMG_Quit();
		TTF_Quit();
		SDL_Quit();
		return -1;
	}
	
	/* Mike's scrolling background code */
	SDL_Texture *texture = LoadTexture("backgroundBMP.bmp", renderer);

	/* what color to clear the background */
	SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 0xff);

	/* create heli sprite */
	if( !heli.load("helicopter2-outlined.png", renderer) ){
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		IMG_Quit();
		TTF_Quit();
		SDL_Quit();
	}

	/* set the heli position */
	heli.setX(50);
	heli.setY(S_HEIGHT);

    /*
    IF YOU EXTEND THE WINDOW SIZE TO INCLUDE 1500 IN THE X COORD YOU WILL SEE THIS VICTIM SPAWN
    ONTO THE SCREEN
    */

    int locx = 100;
    int locy = 0;
    int upordown = 0;   //will building be coming from up or down
    int bigorsmall = 0; //will gap be big or small
    int locationx [10]; //holds x locations
    int locationy [10]; //holds y locations

	/* set the location of building objects */
    for(int i = 0; i<10; i++){
		if(!objarray[i].load("building.png", renderer)){
			SDL_DestroyRenderer(renderer);
			SDL_DestroyWindow(window);
			IMG_Quit();
			TTF_Quit();
			SDL_Quit();
		}
		upordown = (rand()%2); //generates random number 1 is up, 0 is down
		if (upordown == 1){
			locy = 0;
			locationy[i]=locy;
		}
		else {
			locy = 363;
			locationy[i]=locy;
		}
		locationx[i]=locx;
		/* set the obj position*/
		objarray[i].setX(locx);
		objarray[i].setY(locy);

		std::cout<<"Building at location X: "<<locationx[i];
		std::cout<<" Y: "<<locationy[i]<<std::endl;

		bigorsmall = (rand()%2); //1 is 400 away from next, 0 is 350
		if (bigorsmall == 1){
			locx=locx+400;

		}
		else{
			locx=locx+350;
		}
    }
	
	/* create victim sprite */
	if(!victim1.load("victim.png", renderer) || 
	   !victim2.load("victim.png", renderer) ||
	   !victim3.load("victim.png", renderer) ||
	   !victim4.load("victim.png", renderer) ||
	   !victim5.load("victim.png", renderer) ||
	   !victim6.load("victim.png", renderer) ||
	   !victim7.load("victim.png", renderer) ||
	   !victim8.load("victim.png", renderer) ||
	   !victim9.load("victim.png", renderer) ||
	   !victim10.load("victim.png", renderer) ){
        SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		IMG_Quit();
		TTF_Quit();
		SDL_Quit();
	}
	/* set the victim position*/
	victim1.setX(locationx[0] + 50);
	victim1.setY(locationy[0] + 400);

	/* set the victim position*/
    victim2.setX(locationx[1] + 50);
    victim2.setY(locationy[1] - 50);

	/* set the victim position*/
    victim3.setX(locationx[2] + 50);
    victim3.setY(locationy[2] + 400);

	/* set the victim position (off screen)*/
    victim4.setX(locationx[3] + 50);
    victim4.setY(locationy[3] + 400);
	
	victim5.setX(locationx[4] + 50);
    victim5.setY(locationy[4] + 400);
	
	victim6.setX(locationx[5] + 50);
    victim6.setY(locationy[5] - 50);
	
	victim7.setX(locationx[6] + 50);
    victim7.setY(locationy[6] - 50);
	
	victim8.setX(locationx[7] + 50);
    victim8.setY(locationy[7] - 50);
	
	victim9.setX(locationx[8] + 50);
    victim9.setY(locationy[8] - 50);
	
	victim10.setX(locationx[9] + 50);
    victim10.setY(locationy[9] - 50);
	////////////////////////////////
	//         GAME LOOP          //
	////////////////////////////////

	while(isRunning)
	{
		/* update events */
		while( SDL_PollEvent(&event) )
		{
			/* close the window out */
			if( event.type == SDL_QUIT ){
				isRunning = false;
			}

		}
		/* apply velocity, friction, etc... to the helicopter */
		calcVelocity(heli, thrustX, thrustY, vX, vY);

		/* Clear the screen */
		SDL_SetRenderDrawColor( renderer, 0x00, 0x00, 0x00, 0xff);
		SDL_RenderClear(renderer);

		/* move the victims for background scroll each frame */
        victim1.setX(victim1.getX()-SCROLL_SPEED);
        victim2.setX(victim2.getX()-SCROLL_SPEED);
        victim3.setX(victim3.getX()-SCROLL_SPEED);
        victim4.setX(victim4.getX()-SCROLL_SPEED);
        victim5.setX(victim5.getX()-SCROLL_SPEED);
        victim6.setX(victim6.getX()-SCROLL_SPEED);
        victim7.setX(victim7.getX()-SCROLL_SPEED);
        victim8.setX(victim8.getX()-SCROLL_SPEED);
        victim9.setX(victim9.getX()-SCROLL_SPEED);
        victim10.setX(victim10.getX()-SCROLL_SPEED);

		/* move the buildings each frame */
        for(int i=0;i<10;i++){
            objarray[i].setX(objarray[i].getX()-SCROLL_SPEED);
        }

		/* mike's background scrolling */
		cameraRect.x += SCROLL_SPEED; //Makes it an auto scroller
		
		if(cameraRect.x > 3976) {
			std::cout << "Reached End of Level!!!\n";
			cameraRect.x = 3976;
		}			

		/* adapted mike's playerRect to heli sprite */
        if(heli.getX() >= 1024-30){
            heli.setX(1024-31);
            cameraRect.x += 30;
        }
        if(heli.getX() < 15) {
            heli.setX(15);
		}
            //heli.getX() = cameraRect.x+15;
        if(heli.getY() > cameraRect.y+738) {
            heli.setY(cameraRect.y+738);
		}
        if(heli.getY() < cameraRect.y) {
            heli.setY(cameraRect.y);
		}
		
		/* draw's mike's background to the screen */
		SDL_RenderCopy(renderer,texture,&cameraRect,NULL); //copies new render

		/*draw the victims to the screen*/
		for (int i=0;i<10;i++){
            objarray[i].draw(renderer);
		}

        victim1.draw(renderer);
        victim2.draw(renderer);
        victim3.draw(renderer);
        victim4.draw(renderer);
        victim5.draw(renderer);
        victim6.draw(renderer);
        victim7.draw(renderer);
        victim8.draw(renderer);
        victim9.draw(renderer);
        victim10.draw(renderer);

		/* draw the helicopter to the screen */
		heli.draw(renderer);

		/* Update the screen */
		SDL_RenderPresent(renderer);

		/* update miniat */
		if( cycles < MAX_CYCLES ) cycles++;
		miniat_clock(m); // update miniat clock cycle
		clock_peripherals(m, heli, thrustY, vY, lives); // read or write addresses to/from miniat peripherals
		clock_ports(m, vY, thrustY, MAX_VEL); // set port values based on if the helicopter is moving and accelerating
		
		/* regulate FPS */
		SDL_Delay(1000.0f/FPS);
	}

	/* Free memory and exit libraries */
	SDL_DestroyTexture(texture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	IMG_Quit();
	TTF_Quit();
	SDL_Quit();
	
	/* free miniat stuff */
	cleanMiniAT(&m);
	
	/* print how many cycles ran */
	std::cout << "Cycles Ran: " << cycles << std::endl;

	return 0;
}

///////////////////////////////////////
//        FUNCTION DEFINITIONS       //
///////////////////////////////////////
/*
 * initSDL - initializes SDL Library,
 * SDL_ttf library, SDL_image library
 * William Blair
 * 02/16/17
 * */
bool initSDL(void)
{
	/* initialize SDL and check for errors */
	if( SDL_Init(SDL_INIT_VIDEO) < 0 ){
		std::cerr << "Failed to init SDL: " << SDL_GetError()
		                                    << std::endl;
		return false;
	}

	/* Initialze TTF and check for errors */
	if( TTF_Init() == -1 ){
		std::cerr << "Failed to init TTF: " << TTF_GetError()
		                                    << std::endl;
		return false;
	}

	/* Initialize IMG and check for errors */
	int flags = IMG_INIT_JPG | IMG_INIT_PNG;
	int initted = IMG_Init(flags);
	if( initted & flags != flags ){
		std::cerr << "Failed to init IMG: " << IMG_GetError()
		                                    << std::endl;
		return false;
	}

	/* if nothing above failed, return success */
	return true;
}

/*
 * createWindow - initializes a SDL Window
 * and checks for errors
 * William Blair
 * 02/16/17
 * */
bool createWindow(SDL_Window **w)
{
	/* create a window */
	*w = SDL_CreateWindow(title, // title of the window
	                          SDL_WINDOWPOS_UNDEFINED, //x on screen
	                          SDL_WINDOWPOS_UNDEFINED, //y on screen
	                          S_WIDTH,                 // window width
	                          S_HEIGHT,                // window height
	                          SDL_WINDOW_SHOWN ); // display the window

	/* make sure there were no errors creating the window */
	if( !(*w) ){
		std::cerr << "Failed to create window: " << SDL_GetError()
		                                         << std::endl;
		return false;
	}

	/* if no error, return true */
	return true;
}
/*
 * calcVelocity - applies thrust
 * and calculates the helicopter's speed
 * William Blair
 * 02/22/17
 * */
void calcVelocity(Sprite &heli, int thrustX, int thrustY, double &vX, double &vY)
{
	double A_SCALER = 0.004; // scales the thrust into acceleration
	double FRICTION = 0.95; // scales the velocity; simulates air current
	double closeEnough = 0.1; // the minumum vX and vY of the copter to totally stop it

	
	/* calculate acceleration */
	double aX = thrustX * A_SCALER;
	double aY = thrustY * A_SCALER;
	
	/* calculate velocity based on acceleration */
	vX += aX;
	vY += aY;
	
	/* apply friction */
	vX *= FRICTION;
	vY *= FRICTION;
	
	/* apply max velocity */
	if( vX > MAX_VEL ) vX = MAX_VEL;
	else if( vX < -MAX_VEL ) vX = -MAX_VEL;
	if( vY > MAX_VEL ) vY = MAX_VEL;
	else if( vY < -MAX_VEL ) vY = -MAX_VEL;
	

	/* if no thrust applied stop the helicopter if its close enough */
	if( thrustX == 0 && vX > 0){
		if( vX < closeEnough ) vX = 0;
	}
	else if( thrustX == 0 && vX < 0){
		if( vX > -closeEnough ) vX = 0;
	}
	if( thrustY == 0 && vY > 0){
		if( vY < closeEnough ) vY = 0;
	}
	else if( thrustY == 0 && vY < 0){
		if( vY > -closeEnough ) vY = 0;
	}


	/* set the new position of the helicopter, while preventing
	 * it from going offscreen */
	if( ((heli.getX() < S_WIDTH - heli.getW()) && vX > 0) ||
	    (heli.getX() > 0 && vX < 0)) {
		heli.setX( heli.getX() + vX );
		
		/* if the helicopter has moved past the edge of the screen at all 
		 * force it on screen, also reset velocity */
		if( heli.getX() > S_WIDTH - heli.getW() ) {
			heli.setX( S_WIDTH - heli.getW() );
			vX = 0;
		}
		else if(heli.getX() < 0 ) {
			heli.setX(0);
			vX = 0;
		}
	}
	/*if trying to push against either the top or bottom of the screen set the velocity to 0*/
	else{
		vX = 0;
	}
	if( ((heli.getY() < S_HEIGHT - heli.getH()) && vY > 0) ||
	    (heli.getY() > 0 && vY < 0)) {
		heli.setY( heli.getY() + vY );
		
		/* if the helicopter has moved past the edge of the screen at all */
		if( heli.getY() > S_HEIGHT - heli.getH() ) {
			heli.setY( S_HEIGHT - heli.getH() );
			vY = 0;
		}
		else if( heli.getY() < 0 ){
			heli.setY(0);
			vY = 0;
		}
	}
	/*if trying to push against either the top or bottom of the screen set the velocity to 0*/
	else{
		vY = 0;
	}

	return;
}

/*
 * initMiniAT - creates a new miniat system with the given
 * miniat pointer, from compiling the given assembly file
 * William Blair
 * 03/01/17
 * */
bool initMiniAT(miniat **m, int argc, char *argv[])
{
	FILE *binFile = NULL; // the .bin file generated from the asm file
	
	/* signal handlers for if the program ctrl c's */
	signal(SIGINT, signal_handler);
	signal(SIGTERM, signal_handler);
	
	/* cleanup is a function that frees miniat and other stuff */
	// not necessarily needed right now
	//atexit(cleanup);
	
	/* compile asm file if given */
	if( argc != 2 ){
		std::cerr << "No MiniAT assembly file given!\n";
		std::cerr << "Usage: " << argv[0] << " [assembly file]\n";
		return false;
	}
	
	/* delete prviously generated binary file if there is one */
	system("del *.bin");
	
	std::string asmCommand = "mash ";
	asmCommand += argv[1];
	system(asmCommand.c_str()); // mash is the assembler program that generates the .bin file
	
	/* get the new bin file's name 
	 * subtracts the '.asm' suffix from the argument assembly file 
	 * then adds the .bin */
	std::string binStr = "";
	for(int i=0; i<strlen(argv[1])-4; i++ ){
		binStr += argv[1][i];
	} 
	binStr += ".bin";
	std::cout << "Bin File Name = " << binStr << std::endl;
	
	
	/* open the generated .bin file */
	binFile = fopen(binStr.c_str(), "r+b");
	if( !binFile ){
		std::cerr << "Failed to open " << binStr << ": " << strerror(errno)
		                                                 << std::endl;
		std::cerr << "Mash failed to compile?\n";
		return false;
	}
	
	/* init the miniat with the bin file */
	*m = miniat_new(binFile, NULL);
	if( !(*m) ){
		std::cerr << "Failed to create miniat!\n";
		return false;
	}
	std::cout << "Initialized MiniAT!\n";
	
	return true;
}

/* Copied from Confer's example miniat integration (robots) */
static void cleanMiniAT(miniat **m) {

	if(*m) {
		/* MiniAT also closes the binary file it was passed on miniat_new */
		std::cout << "Freeing MiniAT!\n";
		miniat_free(*m);
	}

	/*
	 * Call all the other cleanup functions
	 */
	//peripherals_cleanup();
	//ports_cleanup();

	//if(cycles < MAX_CYCLES) {
		//printf("\n%"PRIu64" cycles executed\n", cycles);
	//}
	//else {
		//printf("Runtime exceeded %"PRIu64" cycles!\n", MAX_CYCLES);
	//}

	//return;
}

/* copied from confer's example miniat integration (robots) 
 * BJ added SDL quit and other stuff */
static void signal_handler(int sig) {

	if(sig == SIGINT || sig == SIGTERM) {
		
		/* close SDL and stuff */
		if( SDL_WasInit(SDL_INIT_VIDEO) != 0){
			SDL_Quit();
			
			/* SDL Image doesn't have a was init function 
			 * so we're assuming if SDL was initted IMG 
			 * was as well */
			IMG_Quit();
		}
		if( TTF_WasInit() ){
			TTF_Quit();
		}
		
		exit(EXIT_SUCCESS);
	}

	return;
}
